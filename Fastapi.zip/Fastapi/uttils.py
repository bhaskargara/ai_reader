import os
import requests
import logging

logger = logging.getLogger(__name__)

def validate_huggingface_token(token):
    """Simple token validation - just check if it exists and starts with hf_"""
    if not token:
        return False
    return token.startswith("hf_") and len(token) > 20


def test_endpoint_accessibility(url, token):
    """Test if an endpoint is accessible"""
    try:
        headers = {"Authorization": f"Bearer {token}"}
        response = requests.post(
            url,
            headers=headers,
            json={"inputs": "test"},
            timeout=15
        )
        return response.status_code in [200, 503]  # 503 means model is loading
    except Exception as e:
        logger.warning(f"Endpoint test failed for {url}: {e}")
        return False

def get_available_models():
    """Get all available model URLs from environment variables"""
    return {
        "google": os.getenv("GOOGLE_MODEL_URL"),
        "facebook": os.getenv("FACEBOOK_MODEL_URL"),
        "meta": os.getenv("META_MODEL_URL"),
        "microsoft": os.getenv("MICROSOFT_MODEL_URL"),
        "huggingface": os.getenv("HUGGINGFACE_MODEL_URL")
    }

def get_selected_model_url():
    """Get the selected model URL based on DEFAULT_MODEL"""
    default_model = os.getenv("DEFAULT_MODEL", "microsoft/DialoGPT-medium")
    
    # Handle model name format like "facebook/bart-large-cnn"
    if "/" in default_model:
        provider = default_model.split("/")[0].upper()
        model_name = default_model.split("/")[1].upper().replace("-", "_")
        
        # Try multiple key formats
        possible_keys = [
            f"{provider}_{model_name}_MODEL_URL",  # FACEBOOK_BART_LARGE_CNN_MODEL_URL
            f"{provider}_MODEL_URL",              # FACEBOOK_MODEL_URL
            f"{default_model.upper().replace('/', '_').replace('-', '_')}_MODEL_URL"  # FACEBOOK_BART_LARGE_CNN_MODEL_URL
        ]
        
        for key in possible_keys:
            model_url = os.getenv(key)
            if model_url:
                logger.info(f"✅ Found model URL using key: {key}")
                break
        else:
            logger.warning(f"❌ Model URL not found for any key: {possible_keys}")
            return None
    else:
        # Handle simple model names
        model_url = os.getenv(f"{default_model.upper()}_MODEL_URL")
        if not model_url:
            logger.warning(f"❌ Model URL not found for key: {default_model.upper()}_MODEL_URL")
            return None
    
    # Validate the URL format
    if not model_url.startswith(("http://", "https://")):
        logger.warning(f"❌ Invalid URL format: {model_url}")
        return None
    
    return model_url

def get_model_config(model_name):
    """Get model-specific configuration"""
    configs = {
        "DialoGPT-medium": {
            "task": "text-generation",
            "model_kwargs": {
                "max_new_tokens": 256,
                "temperature": 0.7,
                "do_sample": True,
                "top_p": 0.95,
                "repetition_penalty": 1.1,
                "pad_token_id": 50256,
                "return_full_text": False
            }
        },
        "flan-t5-base": {
            "task": "text2text-generation",
            "model_kwargs": {
                "max_new_tokens": 256,
                "temperature": 0.7,
                "do_sample": True,
                "top_p": 0.95,
                "repetition_penalty": 1.1
            }
        },
        "bart-large-cnn": {
            "task": "text2text-generation",
            "model_kwargs": {
                "max_new_tokens": 256,
                "temperature": 0.7,
                "do_sample": True,
                "top_p": 0.95,
                "repetition_penalty": 1.1
            }
        },
        "Llama-2-7b-chat-hf": {
            "task": "text-generation",
            "model_kwargs": {
                "max_new_tokens": 256,
                "temperature": 0.7,
                "do_sample": True,
                "top_p": 0.95,
                "repetition_penalty": 1.1,
                "return_full_text": False
            }
        }
    }
    
    return configs.get(model_name, {
        "task": "text-generation",
        "model_kwargs": {
            "max_new_tokens": 256,
            "temperature": 0.7,
            "do_sample": True,
            "top_p": 0.95,
            "repetition_penalty": 1.1,
            "return_full_text": False
        }
    })

def get_model_name_from_url(url):
    """Extract model name from HuggingFace URL"""
    if "bart" in url.lower():
        return "bart-large-cnn"
    elif "dialogpt" in url.lower():
        return "DialoGPT-medium"
    elif "flan-t5" in url.lower():
        return "flan-t5-base"
    elif "llama" in url.lower():
        return "Llama-2-7b-chat-hf"
    else:
        return "custom"
    

# utils.py
# def extract_answer(result: dict) -> str:
#     """
#     Extract the answer text from a LangChain or Hugging Face model result.
#     Handles various formats like dict, list of dicts, or plain strings.
#     """
#     raw_answer = result.get("result") or result.get("answer") or ""

#     if isinstance(raw_answer, list):
#         if raw_answer and isinstance(raw_answer[0], dict):
#             return (
#                 raw_answer[0].get("summary_text") or
#                 raw_answer[0].get("generated_text") or
#                 str(raw_answer[0])
#             )
#         return str(raw_answer[0])

#     elif isinstance(raw_answer, dict):
#         return (
#             raw_answer.get("summary_text") or
#             raw_answer.get("generated_text") or
#             str(raw_answer)
#         )

#     elif isinstance(raw_answer, str):
#         return raw_answer

#     return str(raw_answer)

# STEP 3: Update your extract_answer function to handle all response formats
def extract_answer(result: dict) -> str:
    """
    Extract answer from various response formats
    """
    print(f"🔍 DEBUG - Raw result: {result}")
    print(f"🔍 DEBUG - Result type: {type(result)}")
    
    # Get the raw answer
    raw_answer = result.get("result") or result.get("answer") or result
    
    print(f"🔍 DEBUG - Raw answer: {raw_answer}")
    print(f"🔍 DEBUG - Raw answer type: {type(raw_answer)}")
    
    # Handle list responses
    if isinstance(raw_answer, list):
        if raw_answer and isinstance(raw_answer[0], dict):
            first_item = raw_answer[0]
            print(f"🔍 DEBUG - First item keys: {list(first_item.keys())}")
            
            # Try all possible keys
            answer = (
                first_item.get("summary_text") or
                first_item.get("generated_text") or
                first_item.get("text") or
                first_item.get("translation_text") or
                str(first_item)
            )
            print(f"🔍 DEBUG - Extracted from dict: {answer}")
            return answer
        elif raw_answer:
            answer = str(raw_answer[0])
            print(f"🔍 DEBUG - Extracted from list: {answer}")
            return answer
    
    # Handle dict responses
    elif isinstance(raw_answer, dict):
        print(f"🔍 DEBUG - Dict keys: {list(raw_answer.keys())}")
        answer = (
            raw_answer.get("summary_text") or
            raw_answer.get("generated_text") or
            raw_answer.get("text") or
            raw_answer.get("translation_text") or
            str(raw_answer)
        )
        print(f"🔍 DEBUG - Extracted from dict: {answer}")
        return answer
    
    # Handle string responses
    elif isinstance(raw_answer, str):
        print(f"🔍 DEBUG - String response: {raw_answer}")
        return raw_answer
    
    # Fallback
    final_answer = str(raw_answer)
    print(f"🔍 DEBUG - Final fallback: {final_answer}")
    return final_answer

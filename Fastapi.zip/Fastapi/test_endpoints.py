import requests


def simple_token_test(token):
    try:
        response = requests.get(
            "https://huggingface.co/api/whoami",
            headers={"Authorization": f"Bearer {token}"}
        )
        return response.status_code == 200
    except:
        return False
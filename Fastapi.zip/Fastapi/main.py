"""
FastAPI application for PDF Question-Answering system
Fixed version with updated LangChain methods and better error handling
"""

import os
import sys
import time
import tempfile
import logging
import uuid
import traceback
import json
from contextlib import asynccontextmanager
from typing import Optional
import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.llms.huggingface_endpoint import HuggingFaceEndpoint
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate

# Add parent directory to path for imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from uttils import validate_huggingface_token,get_available_models,get_model_config,test_endpoint_accessibility,get_selected_model_url,get_model_name_from_url,extract_answer
from Schemas import QuestionRequest
from database.database_connection import QdrantDatabase
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.requests import Request
from fastapi import FastAPI, UploadFile, File

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Get folder from .env and ensure it exists
UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
logger.info(f"Upload folder is: {os.path.abspath(UPLOAD_FOLDER)}")

# Global variables
embeddings = None
qdrant_db: QdrantDatabase = None
collection_name = "pdf_documents"
current_collection: Optional[str] = None

# Global tracking
current_collection = None
collection_name = "uploaded_pdf_collection"

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    global embeddings, qdrant_db

    try:
        logger.info("🚀 Starting FastAPI application...")
        
        # Validate environment variables
        if not os.getenv("HUGGINGFACEHUB_API_TOKEN"):
            raise ValueError("HUGGINGFACEHUB_API_TOKEN environment variable is not set")

        # Initialize embeddings
        logger.info("🔧 Initializing embeddings model...")
        embeddings = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2"
        )
        logger.info("✅ Embeddings initialized successfully")

        # Initialize Qdrant database
        logger.info("🔧 Initializing Qdrant database connection...")
        qdrant_db = QdrantDatabase(
            url=os.getenv("QDRANT_URL", "http://localhost:6333"),
            api_key=os.getenv("QDRANT_API_KEY")
        )
        logger.info("✅ Qdrant database connected successfully")

    except Exception as e:
        logger.error(f"❌ Application startup failed: {str(e)}")
        logger.error(traceback.format_exc())
        raise

    yield

    logger.info("🔚 Shutting down FastAPI application")

# Initialize FastAPI app
app = FastAPI(
    title="PDF QA API",
    version="1.0.0",
    description="PDF upload and Question-Answering system using RAG",
    lifespan=lifespan
)


app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/web")
async def serve_web(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})




def initialize_llm_with_fallback():
    """Initialize LLM with proper debugging and fallback strategy."""
    hf_token = os.getenv("HUGGINGFACEHUB_API_TOKEN")

    # List of fallback models
    model_options = [
        {
            "url": "https://api-inference.huggingface.co/models/facebook/bart-large-cnn",
            "name": "bart-large-cnn"
        },
        {
            "url": "https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium",
            "name": "DialoGPT-medium"
        },
        {
            "url": "https://api-inference.huggingface.co/models/google/flan-t5-base",
            "name": "flan-t5-base"
        }
    ]

    # Try custom model first
    try:
        model_url = get_selected_model_url()
        if model_url:
            logger.info(f"🔗 Testing custom model: {model_url}")
            llm = HuggingFaceEndpoint(
                endpoint_url=model_url,
                huggingfacehub_api_token=hf_token,
                model_kwargs={
                    "max_new_tokens": 50,
                    "temperature": 0.3,
                }
            )
            logger.info("✅ Custom model initialized successfully")
            return llm
    except Exception as e:
        logger.warning(f"⚠️ Custom model failed: {str(e)}")

    # Try fallback models
    for model_config in model_options:
        try:
            logger.info(f"🔗 Testing fallback model: {model_config['name']}")
            llm = HuggingFaceEndpoint(
                endpoint_url=model_config["url"],
                huggingfacehub_api_token=hf_token,
                model_kwargs={
                    "max_new_tokens": 50,
                    "temperature": 0.3,
                }
            )
            logger.info(f"✅ {model_config['name']} initialized successfully")
            return llm
        except Exception as e:
            logger.warning(f"⚠️ {model_config['name']} failed: {str(e)}")

    # If all models fail
    raise Exception("All language models failed to initialize")

@app.get("/debug-llm/")
async def debug_llm_endpoint():
    """Debug endpoint to test LLM responses"""
    try:
        hf_token = os.getenv("HUGGINGFACEHUB_API_TOKEN")
        model_url = get_selected_model_url()
        
        if not model_url:
            return {"error": "No model URL found"}
        
    except Exception as e:
        return {"error": str(e)}


def create_simple_llm_response(question, retrieved_docs):
    """Simple fallback response when LLM fails"""
    context_parts = []
    
    for i, doc in enumerate(retrieved_docs[:3]):  # Use top 3 documents
        content = doc.page_content
        if len(content) > 300:
            content = content[:300] + "..."
        context_parts.append(f"Document {i+1}: {content}")
    
    return {
        "answer": f"Based on the retrieved documents, here's the relevant information for your question: '{question}'",
        "context": "\n\n".join(context_parts),
        "source_count": len(retrieved_docs),
        "note": "This response was generated using document retrieval without LLM processing due to model initialization issues."
    }

def process_question_with_llm(question, retrieved_docs):
    """Process question using LLM with fallback options"""
    
    try:
        # Try to initialize LLM
        llm = initialize_llm_with_fallback()
        
        # Create context from retrieved documents
        context = "\n\n".join([
            f"Document {i+1}: {doc.page_content}" 
            for i, doc in enumerate(retrieved_docs[:3])
        ])
        
        # Create a structured prompt
        prompt = f"""Based on the following documents, please provide a concise and accurate answer to the question.

Context Documents:
{context}

Question: {question}

Please provide a direct answer based on the information in the documents above."""
        
        # Generate response
        response = llm.invoke(prompt)
        
        # Clean up the response
        if isinstance(response, str):
            answer = response.strip()
        else:
            answer = str(response).strip()
        
        # Remove any prompt echoing
        if "Question:" in answer:
            answer_parts = answer.split("Question:")
            if len(answer_parts) > 1:
                answer = answer_parts[-1].strip()
        
        return {
            "answer": answer,
            "context": context,
            "source_count": len(retrieved_docs),
            "model_used": "LLM"
        }
        
    except Exception as e:
        logger.error(f"❌ LLM processing failed: {str(e)}")
        # Return simple fallback response
        return create_simple_llm_response(question, retrieved_docs)


@app.get("/")
async def root():
    """Root endpoint for health check"""
    return {
        "message": "PDF QA API is running",
        "version": "1.0.0",
        "status": "healthy"
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        # Check if Qdrant is connected
        if qdrant_db and qdrant_db.is_connected:
            return {
                "status": "healthy",
                "qdrant_connected": True,
                "embeddings_loaded": embeddings is not None,
                "current_collection": current_collection
            }
        else:
            return {
                "status": "unhealthy",
                "qdrant_connected": False,
                "embeddings_loaded": embeddings is not None,
                "current_collection": current_collection
            }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e)
        }

@app.post("/upload/")
async def upload_pdf(file: UploadFile = File(...)):
    """
    Upload and process a PDF file.
    """
    global qdrant_db, current_collection

    try:
        logger.info(f"📤 Received file: {file.filename}")

        # Validate file extension
        if not file.filename.lower().endswith(".pdf"):
            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "message": "Only PDF files are allowed. Please upload a .pdf file."
                }
            )

        # Save file with unique name
        unique_filename = f"{uuid.uuid4().hex[:8]}_{file.filename}"
        file_path = os.path.join(UPLOAD_FOLDER, unique_filename)

        with open(file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)

        logger.info(f"📁 File saved to: {file_path}")

        # Load PDF and split into pages
        loader = PyPDFLoader(file_path)
        pages = loader.load_and_split()

        if not pages:
            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "message": "The uploaded PDF is empty or could not be processed.",
                    "file_path": file_path
                }
            )

        logger.info(f"📄 Loaded {len(pages)} pages")

        # Chunk the document
        splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
        texts = splitter.split_documents(pages)

        logger.info(f"✂️ Split into {len(texts)} text chunks")

        # Unique collection for this file
        unique_collection = f"{collection_name}_{uuid.uuid4().hex[:8]}"

        # Store in Qdrant
        result = qdrant_db.store_documents(texts, unique_collection)

        if not result["success"]:
            raise Exception(result["message"])

        current_collection = unique_collection

        logger.info(f"✅ Stored in Qdrant collection: {unique_collection}")

        return JSONResponse(
            status_code=200,
            content={
                "success": True,
                "message": "PDF processed and stored successfully",
                "filename": file.filename,
                "saved_as": unique_filename,
                "file_path": file_path,
                "collection_name": unique_collection,
                "total_pages": len(pages),
                "total_chunks": len(texts),
                "chunk_size": 1000,
                "chunk_overlap": 200
            }
        )

    except Exception as e:
        logger.error(f"❌ Error: {str(e)}")
        logger.error(traceback.format_exc())
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "message": f"Failed to process PDF: {str(e)}",
                "error_type": type(e).__name__
            }
        )


@app.post("/ask/")
async def ask_question(request: QuestionRequest):
    global qdrant_db, current_collection

    try:
        logger.info(f"❓ Processing question: {request.query}")

        # 🛡 Check if collection exists
        if not current_collection:
            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "message": "No PDF has been uploaded yet. Please upload a PDF first using the /upload/ endpoint."
                }
            )

        # 🛢 Get vector store from Qdrant
        vector_store = qdrant_db.get_vector_store(current_collection)
        if not vector_store:
            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "message": f"Could not access collection '{current_collection}'. Please upload a PDF first."
                }
            )

        # 🔍 Retrieve documents
        logger.info("🔍 Retrieving documents...")
        retriever = vector_store.as_retriever(search_kwargs={"k": request.max_results})
        test_docs = retriever.invoke(request.query)
        logger.info(f"📄 Retrieved {len(test_docs)} documents for context")

        if not test_docs:
            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "message": "No relevant documents found for your query. Please try a different question."
                }
            )

        # 🤖 Initialize LLM
        try:
            logger.info("🤖 Initializing LLM...")
            llm = initialize_llm_with_fallback()
            logger.info("✅ LLM initialized successfully")
        except Exception as e:
            logger.error(f"❌ Error initializing LLM: {str(e)}")
            logger.error(traceback.format_exc())

            # Fallback: return context from retrieved docs
            context = "\n\n".join([doc.page_content for doc in test_docs[:3]])
            sources = [
                {
                    "index": i + 1,
                    "content": doc.page_content[:200] + "..." if len(doc.page_content) > 200 else doc.page_content,
                    "metadata": doc.metadata
                }
                for i, doc in enumerate(test_docs)
            ]

            return JSONResponse(
                status_code=200,
                content={
                    "success": True,
                    "message": "LLM unavailable, returning relevant document excerpts",
                    "question": request.query,
                    "answer": f"Based on the document content, here are the most relevant sections:\n\n{context[:500]}...",
                    "sources_count": len(sources),
                    "sources": sources,
                    "max_results_used": request.max_results,
                    "fallback_used": True,
                    "llm_error": str(e)
                }
            )

        # 🧠 Prompt template
        prompt_template = """Use the following context to answer the question accurately and concisely.
If you don't know the answer based on the context, say "I don't know based on the provided context."

Context: {context}

Question: {question}

Answer:"""

        prompt = PromptTemplate(
            template=prompt_template,
            input_variables=["context", "question"]
        )

        # 🔗 QA Chain
        try:
            logger.info("🔗 Creating QA chain...")
            qa_chain = RetrievalQA.from_chain_type(
                llm=llm,
                chain_type="stuff",
                retriever=retriever,
                chain_type_kwargs={"prompt": prompt},
                return_source_documents=True
            )

            logger.info("🎯 Generating answer...")
            llm_response = qa_chain.invoke({"question": request.query})

            # ✅ Let extract_answer handle different formats like summary_text, generated_text etc.
            answer = extract_answer(llm_response)

            # 📄 Prepare source documents
            sources = []
            for i, doc in enumerate(llm_response.get("source_documents", [])):
                sources.append({
                    "index": i + 1,
                    "content": doc.page_content[:200] + "..." if len(doc.page_content) > 200 else doc.page_content,
                    "metadata": doc.metadata
                })

            logger.info(f"✅ Answer generated successfully for query: {request.query}")

            return JSONResponse(
                status_code=200,
                content={
                    "success": True,
                    "message": "Answer generated successfully",
                    "question": request.query,
                    "answer": answer,
                    "sources_count": len(sources),
                    "sources": sources,
                    "max_results_used": request.max_results,
                    "collection_used": current_collection,
                    "model_used": getattr(llm, "_model_name", "Unknown")
                }
            )

        except Exception as e:
            logger.error(f"❌ Error in QA chain: {str(e)}")
            logger.error(traceback.format_exc())

            # Final fallback: return retrieved context
            try:
                context = "\n\n".join([doc.page_content for doc in test_docs[:3]])
                fallback_answer = f"Based on the document content, here are the most relevant sections:\n\n{context[:500]}..."

                sources = [
                    {
                        "index": i + 1,
                        "content": doc.page_content[:200] + "..." if len(doc.page_content) > 200 else doc.page_content,
                        "metadata": doc.metadata
                    }
                    for i, doc in enumerate(test_docs)
                ]

                return JSONResponse(
                    status_code=200,
                    content={
                        "success": True,
                        "message": "Answer generated using fallback method",
                        "question": request.query,
                        "answer": fallback_answer,
                        "sources_count": len(sources),
                        "sources": sources,
                        "max_results_used": request.max_results,
                        "fallback_used": True
                    }
                )
            except Exception as fallback_error:
                logger.error(f"❌ Fallback also failed: {str(fallback_error)}")
                return JSONResponse(
                    status_code=500,
                    content={
                        "success": False,
                        "message": f"Both main and fallback methods failed. Main error: {str(e)}",
                        "error_type": type(e).__name__
                    }
                )

    except Exception as e:
        logger.error(f"❌ Error processing question: {str(e)}")
        logger.error(traceback.format_exc())

        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "message": f"Failed to process question: {str(e)}",
                "error_type": type(e).__name__,
                "current_collection": current_collection
            }
        )

@app.get("/collections/")
async def list_collections():
    """List all available collections"""
    global qdrant_db
    
    try:
        if not qdrant_db:
            return JSONResponse(
                status_code=500,
                content={
                    "success": False,
                    "message": "Qdrant database not initialized"
                }
            )
        
        result = qdrant_db.list_collections()
        
        # Add current collection info
        result["current_collection"] = current_collection
        
        return JSONResponse(
            status_code=200,
            content=result
        )
    
    except Exception as e:
        logger.error(f"❌ Error listing collections: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "message": f"Failed to list collections: {str(e)}"
            }
        )

@app.delete("/collections/{collection_name}")
async def delete_collection(collection_name: str):
    """Delete a specific collection"""
    global qdrant_db, current_collection
    
    try:
        if not qdrant_db:
            return JSONResponse(
                status_code=500,
                content={
                    "success": False,
                    "message": "Qdrant database not initialized"
                }
            )
        
        result = qdrant_db.delete_collection(collection_name)
        
        # If we deleted the current collection, reset it
        if collection_name == current_collection:
            current_collection = None
        
        if result["success"]:
            return JSONResponse(
                status_code=200,
                content=result
            )
        else:
            return JSONResponse(
                status_code=404,
                content=result
            )
    
    except Exception as e:
        logger.error(f"❌ Error deleting collection: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "message": f"Failed to delete collection: {str(e)}"
            }
        )

@app.get("/collections/{collection_name}/info")
async def get_collection_info(collection_name: str):
    """Get information about a specific collection"""
    global qdrant_db
    
    try:
        if not qdrant_db:
            return JSONResponse(
                status_code=500,
                content={
                    "success": False,
                    "message": "Qdrant database not initialized"
                }
            )
        
        result = qdrant_db.get_collection_info(collection_name)
        
        if result["success"]:
            return JSONResponse(
                status_code=200,
                content=result
            )
        else:
            return JSONResponse(
                status_code=404,
                content=result
            )
    
    except Exception as e:
        logger.error(f"❌ Error getting collection info: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "message": f"Failed to get collection info: {str(e)}"
            }
        )

@app.post("/search/")
async def search_documents(request: dict):
    """
    Search for documents in a collection
    
    Args:
        request: Dict with query, collection_name, and top_k
        
    Returns:
        JSON response with search results
    """
    global qdrant_db
    
    try:
        query = request.get("query")
        collection_name = request.get("collection_name", current_collection)
        top_k = request.get("top_k", 5)
        
        if not query:
            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "message": "'query' is required"
                }
            )
        
        if not collection_name:
            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "message": "'collection_name' is required or no current collection set"
                }
            )
        
        if not qdrant_db:
            return JSONResponse(
                status_code=500,
                content={
                    "success": False,
                    "message": "Qdrant database not initialized"
                }
            )
        
        result = qdrant_db.search_documents(query, collection_name, top_k)
        
        return JSONResponse(
            status_code=200,
            content=result
        )
    
    except Exception as e:
        logger.error(f"❌ Error searching documents: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "message": f"Failed to search documents: {str(e)}"
            }
        )

@app.get("/test-llm/")
async def test_llm():
    """Test LLM initialization and connection"""
    try:
        logger.info("🧪 Testing LLM initialization...")
        
        # Try to initialize LLM
        llm = initialize_llm_with_fallback()
        
        # Test with a simple query
        test_query = "Hello, how are you?"
        response = llm.invoke(test_query)
        
        return JSONResponse(
            status_code=200,
            content={
                "success": True,
                "message": "LLM is working properly",
                "test_query": test_query,
                "test_response": response[:200] + "..." if len(str(response)) > 200 else str(response)
            }
        )
        
    except Exception as e:
        logger.error(f"❌ LLM test failed: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "message": f"LLM test failed: {str(e)}",
                "error_type": type(e).__name__
            }
        )

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
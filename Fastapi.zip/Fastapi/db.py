from database.database_connection import QdrantDatabase

qdrant = QdrantDatabase()
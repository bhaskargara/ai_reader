#!/usr/bin/env python3
"""
Test different HuggingFace models to find working ones
"""

import os
import requests
from dotenv import load_dotenv
import time

def test_model(model_name, token):
    """Test a specific model"""
    url = f"https://api-inference.huggingface.co/models/{model_name}"
    headers = {"Authorization": f"Bearer {token}"}
    
    try:
        response = requests.post(
            url, 
            headers=headers, 
            json={"inputs": "Hello, how are you?"}, 
            timeout=15
        )
        
        return response.status_code, response.text[:200]
    except Exception as e:
        return "ERROR", str(e)

def main():
    # Load environment
    load_dotenv()
    
    token = os.getenv("HUGGINGFACEHUB_API_TOKEN")
    
    if not token:
        print("❌ No HUGGINGFACEHUB_API_TOKEN found")
        return
    
    print(f"🔍 Testing with token: {token[:20]}...")
    
    # Test different models that are known to work with Inference API
    models_to_test = [
        # Text Generation Models
        "gpt2",
        "microsoft/DialoGPT-small",
        "microsoft/DialoGPT-medium",
        "microsoft/DialoGPT-large",
        "facebook/blenderbot-400M-distill",
        "facebook/blenderbot_small-90M",
        "google/flan-t5-small",
        "google/flan-t5-base",
        "huggingface/CodeBERTa-small-v1",
        "distilbert-base-uncased-finetuned-sst-2-english",
        "cardiffnlp/twitter-roberta-base-sentiment-latest",
        # Newer models
        "microsoft/DialoGPT-medium",
        "facebook/bart-large-cnn",
        "t5-small",
        "t5-base"
    ]
    
    working_models = []
    
    print("\n🧪 Testing models...")
    print("=" * 80)
    
    for i, model in enumerate(models_to_test, 1):
        print(f"\n[{i}/{len(models_to_test)}] Testing: {model}")
        
        status_code, response = test_model(model, token)
        
        if status_code == 200:
            print(f"✅ WORKING: {model}")
            working_models.append(model)
        elif status_code == 503:
            print(f"⏳ LOADING: {model} (model is loading, try again later)")
            working_models.append(model)  # Still valid
        elif status_code == 401:
            print(f"🔑 AUTH ERROR: Invalid token")
            break
        elif status_code == 404:
            print(f"❌ NOT FOUND: {model}")
        else:
            print(f"⚠️ ERROR {status_code}: {model}")
            print(f"   Response: {response[:100]}...")
        
        # Small delay to avoid rate limiting
        time.sleep(1)
    
    print("\n" + "=" * 80)
    print("📊 RESULTS SUMMARY")
    print("=" * 80)
    
    if working_models:
        print(f"✅ Found {len(working_models)} working models:")
        for model in working_models:
            print(f"   • {model}")
        
        print(f"\n🎯 RECOMMENDED MODEL: {working_models[0]}")
        print(f"🔗 URL: https://api-inference.huggingface.co/models/{working_models[0]}")
        
        # Generate .env content
        print("\n📝 UPDATE YOUR .env FILE:")
        print("=" * 40)
        print(f"HUGGINGFACEHUB_API_TOKEN={token}")
        print(f"DEFAULT_MODEL={working_models[0]}")
        print(f"MICROSOFT_MODEL_URL=https://api-inference.huggingface.co/models/{working_models[0]}")
        
        if len(working_models) > 1:
            print(f"GOOGLE_MODEL_URL=https://api-inference.huggingface.co/models/{working_models[1]}")
        if len(working_models) > 2:
            print(f"FACEBOOK_MODEL_URL=https://api-inference.huggingface.co/models/{working_models[2]}")
    else:
        print("❌ No working models found!")
        print("💡 Possible solutions:")
        print("   1. Check if your token is valid")
        print("   2. Try again later (models might be loading)")
        print("   3. Create a new HuggingFace token")
        print("   4. Use a different model provider")

if __name__ == "__main__":
    main()
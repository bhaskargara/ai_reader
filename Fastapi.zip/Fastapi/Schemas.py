from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional

class QuestionRequest(BaseModel):
    """Request model for asking questions about PDF content"""
    query: str = Field(..., min_length=1, max_length=1000, description="The question to ask")
    max_results: int = Field(default=4, ge=1, le=10, description="Maximum number of document chunks to retrieve")

    class Config:
        json_schema_extra = {
            "example": {
                "query": "What is the main topic discussed in this document?",
                "max_results": 4
            }
        }

class QuestionResponse(BaseModel):
    """Response model for question answers"""
    question: str = Field(..., description="The original question asked")
    answer: str = Field(..., description="The AI-generated answer")
    sources: List[str] = Field(..., description="Relevant excerpts from the document")

    class Config:
        json_schema_extra = {
            "example": {
                "question": "What is the main topic discussed in this document?",
                "answer": "The main topic is artificial intelligence and its applications in modern technology.",
                "sources": ["This document explores AI technologies...", "Machine learning algorithms are discussed..."]
            }
        }

class UploadResponse(BaseModel):
    """Response model for PDF upload operations"""
    message: str = Field(..., description="Status message")
    success: bool = Field(..., description="Whether the operation succeeded")
    status_code: int = Field(..., description="HTTP status code")
    data: Optional[Dict[str, Any]] = Field(None, description="Additional upload information")

    class Config:
        json_schema_extra = {
            "example": {
                "message": "PDF uploaded and processed successfully.",
                "success": True,
                "status_code": 200,
                "data": {
                    "pages_processed": 15,
                    "chunks_created": 42,
                    "filename": "document.pdf"
                }
            }
        }

class HealthResponse(BaseModel):
    """Response model for health check"""
    message: str = Field(..., description="Health status message")
    success: bool = Field(..., description="Whether the service is healthy")
    status_code: int = Field(..., description="HTTP status code")
    vector_store_loaded: bool = Field(..., description="Whether a PDF has been loaded")

    class Config:
        json_schema_extra = {
            "example": {
                "message": "Service is healthy.",
                "success": True,
                "status_code": 200,
                "vector_store_loaded": True
            }
        }

class ResetResponse(BaseModel):
    """Response model for reset operations"""
    message: str = Field(..., description="Reset status message")
    success: bool = Field(..., description="Whether the reset succeeded")
    status_code: int = Field(..., description="HTTP status code")

    class Config:
        json_schema_extra = {
            "example": {
                "message": "Vector store reset successfully.",
                "success": True,
                "status_code": 200
            }
        }

// Global variables
let currentCollection = null;
let currentAnswer = null;
let isRecording = false;
let recognition = null;
let isProcessing = false;

// DOM elements
const pdfUpload = document.getElementById("pdfUpload");
const uploadBtn = document.getElementById("uploadBtn");
const askBtn = document.getElementById("askBtn");
const voiceBtn = document.getElementById("voiceBtn");
const sendVoiceBtn = document.getElementById("sendVoiceBtn");
const speakAnswerBtn = document.getElementById("speakAnswerBtn");
const questionInput = document.getElementById("questionInput");
const answerBox = document.getElementById("answerBox");
const sourcesBox = document.getElementById("sourcesBox");

// Event listeners
uploadBtn.addEventListener("click", uploadPDF);
askBtn.addEventListener("click", askQuestion);
voiceBtn.addEventListener("click", toggleVoiceRecording);
sendVoiceBtn.addEventListener("click", askQuestion);
speakAnswerBtn.addEventListener("click", toggleSpeech);

// Initialize speech recognition
function initializeSpeechRecognition() {
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    console.warn("Speech recognition not supported in this browser");
    voiceBtn.style.display = "none";
    return;
  }

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SpeechRecognition();
  
  recognition.lang = "en-IN";
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.onstart = () => {
    console.log("Speech recognition started");
    isRecording = true;
    voiceBtn.classList.add("listening");
    voiceBtn.title = "Listening... Click to stop";
  };

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    console.log("Speech recognition result:", transcript);
    questionInput.value = transcript;
    sendVoiceBtn.style.display = "inline-block";
    showMessage("Voice input captured successfully!", "success");
  };

  recognition.onend = () => {
    console.log("Speech recognition ended");
    isRecording = false;
    voiceBtn.classList.remove("listening");
    voiceBtn.title = "Voice Input";
  };

  recognition.onerror = (event) => {
    console.error("Speech recognition error:", event.error);
    isRecording = false;
    voiceBtn.classList.remove("listening");
    voiceBtn.title = "Voice Input";
    showMessage(`Voice recognition error: ${event.error}`, "error");
  };
}

// Voice recording toggle
function toggleVoiceRecording() {
  if (!recognition) {
    initializeSpeechRecognition();
    if (!recognition) {
      showMessage("Speech recognition not available in this browser", "error");
      return;
    }
  }

  if (isRecording) {
    recognition.stop();
  } else {
    try {
      recognition.start();
    } catch (error) {
      console.error("Error starting speech recognition:", error);
      showMessage("Could not start voice recording", "error");
    }
  }
}

// Upload PDF function
async function uploadPDF() {
  const file = pdfUpload.files[0];
  
  if (!file) {
    showMessage("Please select a PDF file first", "error");
    return;
  }
  
  if (file.type !== "application/pdf") {
    showMessage("Please select a valid PDF file", "error");
    return;
  }

  if (file.size > 10 * 1024 * 1024) { // 10MB limit
    showMessage("File size too large. Please select a file smaller than 10MB", "error");
    return;
  }

  const formData = new FormData();
  formData.append("file", file);

  // Show loading state
  setLoadingState(uploadBtn, true, "Uploading...");

  try {
    const response = await fetch("/upload/", {
      method: "POST",
      body: formData,
    });

    const result = await response.json();
    
    if (result.success) {
      currentCollection = result.collection_name;
      showMessage(`PDF uploaded successfully! Collection: ${result.collection_name}`, "success");
      console.log("Upload result:", result);
      
      // Enable question input
      questionInput.disabled = false;
      askBtn.disabled = false;
      voiceBtn.disabled = false;
    } else {
      showMessage(`Upload failed: ${result.message}`, "error");
      console.error("Upload failed:", result);
    }
  } catch (error) {
    console.error("Upload error:", error);
    showMessage("Error uploading PDF. Please try again.", "error");
  } finally {
    setLoadingState(uploadBtn, false, "Upload PDF");
  }
}

// Ask question function
async function askQuestion() {
  const question = questionInput.value.trim();
  
  if (!question) {
    showMessage("Please enter a question", "error");
    return;
  }
  
  if (!currentCollection) {
    showMessage("Please upload a PDF first", "error");
    return;
  }

  if (isProcessing) {
    showMessage("Please wait for the current question to complete", "error");
    return;
  }

  const payload = {
    query: question,
    max_results: 3,
    collection_name: currentCollection
  };

  // Show loading state
  isProcessing = true;
  setLoadingState(askBtn, true, "Processing...");
  answerBox.textContent = "🔍 Searching through your PDF...";
  sourcesBox.textContent = "🔍 Finding relevant sources...";
  speakAnswerBtn.style.display = "none";
  sendVoiceBtn.style.display = "none";

  try {
    const response = await fetch("/ask/", {
      method: "POST",
      headers: { 
        "Content-Type": "application/json" 
      },
      body: JSON.stringify(payload),
    });

    const result = await response.json();
    console.log("Ask result:", result);
    
    if (result.success) {
      currentAnswer = result.answer;
      answerBox.textContent = result.answer;
      
      // Display sources with better formatting
      if (result.sources && result.sources.length > 0) {
        sourcesBox.innerHTML = result.sources.map((source, index) => `
          <div class="source-item">
            <strong>📄 Source ${index + 1}:</strong> 
            <span class="source-page">Page ${source.metadata?.page || "Unknown"}</span>
            <p>${source.content}</p>
          </div>
        `).join("");
      } else {
        sourcesBox.textContent = "No sources found";
      }
      
      speakAnswerBtn.style.display = "block";
      showMessage("Answer generated successfully!", "success");
    } else {
      answerBox.textContent = `❌ Failed to get answer: ${result.message}`;
      sourcesBox.textContent = "No sources available";
      showMessage(`Failed to get answer: ${result.message}`, "error");
    }
  } catch (error) {
    console.error("Ask error:", error);
    answerBox.textContent = "❌ Error occurred while fetching answer. Please try again.";
    sourcesBox.textContent = "Error retrieving sources";
    showMessage("Error occurred while fetching answer", "error");
  } finally {
    isProcessing = false;
    setLoadingState(askBtn, false, "Ask Question");
  }
}

// Text-to-speech function
function toggleSpeech() {
  if (!currentAnswer) {
    showMessage("No answer available to speak", "error");
    return;
  }

  const synth = window.speechSynthesis;

  if (synth.speaking) {
    synth.cancel();
    speakAnswerBtn.textContent = "🔊 Speak Answer";
    speakAnswerBtn.title = "Speak Answer";
  } else {
    const utterance = new SpeechSynthesisUtterance(currentAnswer);
    utterance.lang = "en-IN";
    utterance.rate = 0.8;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    utterance.onstart = () => {
      speakAnswerBtn.textContent = "🛑 Stop Speaking";
      speakAnswerBtn.title = "Stop Speaking";
    };

    utterance.onend = () => {
      speakAnswerBtn.textContent = "🔊 Speak Answer";
      speakAnswerBtn.title = "Speak Answer";
    };

    utterance.onerror = (event) => {
      console.error("Speech synthesis error:", event.error);
      speakAnswerBtn.textContent = "🔊 Speak Answer";
      speakAnswerBtn.title = "Speak Answer";
      showMessage("Error in speech synthesis", "error");
    };

    synth.speak(utterance);
  }
}

// Utility functions
function showMessage(message, type = "info") {
  // Remove existing messages
  const existingMessages = document.querySelectorAll(".message");
  existingMessages.forEach(msg => msg.remove());

  // Create new message element
  const messageElement = document.createElement("div");
  messageElement.className = `message ${type}`;
  messageElement.textContent = message;

  // Insert after the title
  const container = document.querySelector(".container");
  const title = container.querySelector("h1");
  title.insertAdjacentElement("afterend", messageElement);

  // Auto-remove after 5 seconds
  setTimeout(() => {
    messageElement.remove();
  }, 5000);
}

function setLoadingState(button, isLoading, loadingText) {
  if (isLoading) {
    button.disabled = true;
    button.dataset.originalText = button.textContent;
    button.textContent = loadingText;
    button.classList.add("loading");
  } else {
    button.disabled = false;
    button.textContent = button.dataset.originalText || button.textContent;
    button.classList.remove("loading");
  }
}

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  console.log("PDF QA Assistant initialized");
  
  // Initialize speech recognition
  initializeSpeechRecognition();
  
  // Disable question input initially
  questionInput.disabled = true;
  askBtn.disabled = true;
  voiceBtn.disabled = true;
  
  // Add placeholder text
  answerBox.textContent = "Upload a PDF and ask a question to get started...";
  sourcesBox.textContent = "Source documents will appear here...";
  
  // Add file change listener
  pdfUpload.addEventListener("change", (event) => {
    const file = event.target.files[0];
    if (file) {
      showMessage(`Selected: ${file.name} (${(file.size / 1024 / 1024).toFixed(2)} MB)`, "info");
    }
  });
  
  // Add enter key listener for question input
  questionInput.addEventListener("keypress", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      askQuestion();
    }
  });
  
  // Clear voice input when manually typing
  questionInput.addEventListener("input", () => {
    if (sendVoiceBtn.style.display === "inline-block") {
      sendVoiceBtn.style.display = "none";
    }
  });
});

// Handle page visibility change (stop speech when page hidden)
document.addEventListener("visibilitychange", () => {
  if (document.hidden) {
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
    }
    if (isRecording && recognition) {
      recognition.stop();
    }
  }
});
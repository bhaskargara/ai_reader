# import requests

# url = "https://api-inference.huggingface.co/models/tiiuae/falcon-7b-instruct"
# headers = {
#     "Authorization": "Bearer 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"
# }
# data = {
#     "inputs": "What is the capital of India?"
# }

# res = requests.post(url, headers=headers, json=data)
# print(res.status_code, res.text)


# # At the top of your main.py file
# import os
# from dotenv import load_dotenv

# # Load environment variables
# load_dotenv()

# # Get upload folder from environment or use default
# UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", "uploads")

# # Create upload folder programmatically (not manually)
# os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# print(f"Upload folder created: {UPLOAD_FOLDER}")
# print(f"Full path: {os.path.abspath(UPLOAD_FOLDER)}")



#!/usr/bin/env python3
"""
Complete test script for RAG system
Save this as helper.py and run with: python helper.py
"""

import os
import sys
import requests

# Try to load dotenv, but don't fail if it's not available
try:
    from dotenv import load_dotenv
    load_dotenv()
    print("✅ Loaded .env file")
except ImportError:
    print("⚠️ python-dotenv not installed, reading environment variables directly")
except Exception as e:
    print(f"⚠️ Could not load .env file: {e}")
    print("📝 Make sure your .env file is in the same directory as helper.py")

def test_environment_variables():
    """Test if all required environment variables are set"""
    print("🔍 Testing Environment Variables...")
    
    required_vars = [
        "HUGGINGFACEHUB_API_TOKEN",
        "DEFAULT_MODEL",
        "MICROSOFT_MODEL_URL",
        "GOOGLE_MODEL_URL",
        "FACEBOOK_MODEL_URL"
    ]
    
    missing_vars = []
    for var in required_vars:
        value = os.getenv(var)
        if not value:
            missing_vars.append(var)
        else:
            print(f"✅ {var}: {value[:50]}...")
    
    if missing_vars:
        print(f"❌ Missing environment variables: {missing_vars}")
        return False
    
    print("✅ All environment variables are set")
    return True

def test_huggingface_token():
    """Test HuggingFace API token"""
    print("\n🔍 Testing HuggingFace Token...")
    
    token = os.getenv("HUGGINGFACEHUB_API_TOKEN")
    if not token:
        print("❌ No HuggingFace token found")
        return False
    
    # Test with a simple model
    url = "https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium"
    headers = {"Authorization": f"Bearer {token}"}
    data = {"inputs": "Hello, how are you?"}
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=30)
        print(f"Response Status: {response.status_code}")
        
        if response.status_code == 200:
            print("✅ HuggingFace token is working!")
            return True
        elif response.status_code == 503:
            print("⚠️ Model is loading, but token is valid")
            return True
        else:
            print(f"❌ Token test failed: {response.status_code}")
            print(f"Response: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ Request failed: {str(e)}")
        return False

def test_qdrant_connection():
    """Test Qdrant connection"""
    print("\n🔍 Testing Qdrant Connection...")
    
    try:
        response = requests.get("http://localhost:6333/collections", timeout=10)
        if response.status_code == 200:
            print("✅ Qdrant is accessible")
            collections = response.json()
            print(f"📊 Found {len(collections.get('result', {}).get('collections', []))} collections")
            return True
        else:
            print(f"❌ Qdrant connection failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Qdrant connection failed: {str(e)}")
        print("💡 Make sure Qdrant is running: docker run -p 6333:6333 qdrant/qdrant")
        return False

def test_model_endpoints():
    """Test all model endpoints"""
    print("\n🔍 Testing Model Endpoints...")
    
    token = os.getenv("HUGGINGFACEHUB_API_TOKEN")
    models = {
        "Microsoft DialoGPT": os.getenv("MICROSOFT_MODEL_URL"),
        "Google Flan-T5": os.getenv("GOOGLE_MODEL_URL"),
        "Facebook BART": os.getenv("FACEBOOK_MODEL_URL"),
        "Meta Llama": os.getenv("META_MODEL_URL"),
        "Custom HuggingFace": os.getenv("HUGGINGFACE_MODEL_URL")
    }
    
    working_models = []
    
    for name, url in models.items():
        if not url:
            print(f"⚠️ {name}: No URL configured")
            continue
        
        try:
            headers = {"Authorization": f"Bearer {token}"}
            response = requests.post(
                url,
                headers=headers,
                json={"inputs": "test"},
                timeout=15
            )
            
            if response.status_code in [200, 503]:
                print(f"✅ {name}: Working")
                working_models.append(name)
            else:
                print(f"❌ {name}: Failed ({response.status_code})")
                
        except Exception as e:
            print(f"❌ {name}: Failed ({str(e)})")
    
    print(f"\n📊 {len(working_models)} out of {len(models)} models are working")
    return len(working_models) > 0

def test_fastapi_server():
    """Test if FastAPI server is running"""
    print("\n🔍 Testing FastAPI Server...")
    
    try:
        response = requests.get("http://localhost:8000/", timeout=10)
        if response.status_code == 200:
            print("✅ FastAPI server is running")
            return True
        else:
            print(f"❌ FastAPI server responded with: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ FastAPI server is not accessible: {str(e)}")
        print("💡 Start your server with: uvicorn main:app --reload")
        return False

def main():
    """Run all tests"""
    print("🚀 Starting RAG System Tests\n")
    
    tests = [
        ("Environment Variables", test_environment_variables),
        ("HuggingFace Token", test_huggingface_token),
        ("Qdrant Connection", test_qdrant_connection),
        ("Model Endpoints", test_model_endpoints),
        ("FastAPI Server", test_fastapi_server)
    ]
    
    results = []
    for test_name, test_func in tests:
        result = test_func()
        results.append((test_name, result))
    
    print("\n" + "="*50)
    print("📊 TEST RESULTS SUMMARY")
    print("="*50)
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{test_name}: {status}")
        if result:
            passed += 1
    
    print(f"\n🎯 {passed}/{len(tests)} tests passed")
    
    if passed == len(tests):
        print("\n🎉 All tests passed! Your RAG system should be working.")
    else:
        print("\n⚠️ Some tests failed. Check the output above for details.")
    
    return passed == len(tests)

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)